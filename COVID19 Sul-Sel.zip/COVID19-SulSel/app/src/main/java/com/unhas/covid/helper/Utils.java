package com.unhas.covid.helper;

public class Utils {
    //This is your from email
    public static final String EMAIL = "info@covid19.kuycoding.com";
    //This is your from email password
    public static final String PASSWORD = "passwd";
}
