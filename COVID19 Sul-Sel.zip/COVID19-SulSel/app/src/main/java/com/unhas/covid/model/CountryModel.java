package com.unhas.covid.model;

import com.google.gson.annotations.SerializedName;

public class CountryModel {
    @SerializedName("name")
    private String namel;

    @SerializedName("positif")
    private String  idnConfirmed;

    @SerializedName("sembuh")
    private String idnRecovered;

    @SerializedName("meninggal")
    private String idnDeaths;

    public CountryModel(String namel, String idnConfirmed, String idnRecovered, String idnDeaths) {
        this.namel = namel;
        this.idnConfirmed = idnConfirmed;
        this.idnRecovered = idnRecovered;
        this.idnDeaths = idnDeaths;
    }

    public String getNamel() {
        return namel;
    }

    public String getIdnConfirmed() {
        return idnConfirmed;
    }

    public String getIdnRecovered() {
        return idnRecovered;
    }

    public String getIdnDeaths() {
        return idnDeaths;
    }
}
