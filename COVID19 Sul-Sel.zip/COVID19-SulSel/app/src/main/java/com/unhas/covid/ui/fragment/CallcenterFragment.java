package com.unhas.covid.ui.fragment;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.unhas.covid.R;
import com.unhas.covid.ui.activities.bantuan.HospitalActivity;
import com.unhas.covid.ui.activities.bantuan.HotlineActivity;
/**
 * A simple {@link Fragment} subclass.
 */
public class CallcenterFragment extends Fragment implements View.OnClickListener {
    private LinearLayout layout_hotline, layout_rs, layout_qna, layout_contact;
    private EditText edNama, edEmail, edPesan;
    private ImageButton btnClose;

    public CallcenterFragment() {
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_callcenter, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        layout_hotline = view.findViewById(R.id.layout_hotline);
        layout_hotline.setOnClickListener(this);

        layout_rs = view.findViewById(R.id.layout_rs);
        layout_rs.setOnClickListener(this);

        layout_qna = view.findViewById(R.id.layout_qna);
        layout_qna.setOnClickListener(this);
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.layout_hotline:
                startActivity(new Intent(getContext(), HotlineActivity.class));
                break;
            case R.id.layout_rs:
                Intent intent = new Intent(getContext(), HospitalActivity.class);
                startActivity(intent);
                break;
            case R.id.layout_qna:
                String url = "http://covid19.sulselprov.go.id";
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(url));
                startActivity(i);
                break;
        }
    }
}
