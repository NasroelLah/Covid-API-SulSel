package com.unhas.covid.ui.fragment;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.unhas.covid.R;
import com.unhas.covid.model.CountryModel;
import com.unhas.covid.model.SulselModel;
import com.unhas.covid.ui.activities.CaseIndoActivity;
import com.unhas.covid.ui.activities.SulselActivity;
import com.unhas.covid.viewModel.CountryViewModel;
import com.unhas.covid.viewModel.SulselViewModel;

/**
 * A simple {@link Fragment} subclass.
 */
public class HomeFragment extends Fragment {
    private TextView tvPositif;
    private TextView tvSembuh;
    private TextView tvMeninggal;

    private TextView tvIdRecovered;
    private TextView tvIdConfirmed;
    private TextView tvLocate;
    private TextView tvIdDeath;

    private CardView cardView_indo;
    private CardView cardView_sulsel;
    private static final int[] COLOR_CUSTOM = {
            rgb("#FF5722"), rgb("#8aca2b"), rgb("#E91E63"), rgb("#3498db")
    };
    private static int rgb(String hex) {
        int color = (int) Long.parseLong(hex.replace("#", ""), 16);
        int r = (color >> 16) & 0xFF;
        int g = (color >> 8) & 0xFF;
        int b = (color) & 0xFF;
        return Color.rgb(r, g, b);
    }

    public HomeFragment() {
        // Required empty public constructor
    }


    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_home, container, false);
    }

    @SuppressLint("SetTextI18n")
    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        tvPositif = view.findViewById(R.id.txt_positif);
        tvSembuh = view.findViewById(R.id.txt_sembuh);
        tvMeninggal = view.findViewById(R.id.txt_meninggal);

        tvIdConfirmed = view.findViewById(R.id.txt_confirmed1);
        tvIdRecovered = view.findViewById(R.id.txt_rcv);
        tvIdDeath = view.findViewById(R.id.txt_death);
        tvLocate = view.findViewById(R.id.txt_location);
        view.findViewById(R.id.txt_location);

        cardView_indo = view.findViewById(R.id.cardView_indo);
        cardView_indo.setOnClickListener(v -> startActivity(new Intent(getContext(), CaseIndoActivity.class)));
        cardView_sulsel = view.findViewById(R.id.cardView_sulsel);
        cardView_sulsel.setOnClickListener(v -> startActivity(new Intent(getContext(), SulselActivity.class)));

        SulselViewModel sulselViewModel = new ViewModelProvider(this,
                new ViewModelProvider.NewInstanceFactory()).get(SulselViewModel.class);
        sulselViewModel.setSulselData();
        sulselViewModel.getSulselData().observe(getViewLifecycleOwner(), sulselModels -> {
            SulselModel sulselModel = sulselModels.get(0);
            String odp = sulselModel.getOdp();
            String totalOdp = sulselModel.getTotalOdp();
            String selesaiOdp = sulselModel.getSelesaiOdp();
            String pdp = sulselModel.getPdp();
            String pdpMeninggal = sulselModel.getDiePdp();
            String pdpNegatif = sulselModel.getNegatifPdp();
            String totalPdp = sulselModel.getTotalPdp();
            String positif = sulselModel.getPositif();
            String isolasiMandiri = sulselModel.getIsolasiMandiri();
            String isolasiRs = sulselModel.getIsolasiRs();
            String sembuh = sulselModel.getSembuh();
            String meninggal = sulselModel.getMeninggal();
            String totalPositif = sulselModel.getTotalPositif();

            tvPositif.setText(positif);
            tvMeninggal.setText(meninggal);
            tvSembuh.setText(sembuh);
        });

        CountryViewModel countryViewModel = new ViewModelProvider(this,
                new ViewModelProvider.NewInstanceFactory()).get(CountryViewModel.class);
        countryViewModel.setCountryData();
        countryViewModel.getCountryData().observe(getViewLifecycleOwner(), countryModels -> {
            CountryModel countryModel = countryModels.get(0);
            String nama = countryModel.getNamel();
            String confirmed = countryModel.getIdnConfirmed();
            String recovered = countryModel.getIdnRecovered();
            String death = countryModel.getIdnDeaths();

            tvIdConfirmed.setText(confirmed);
            tvIdRecovered.setText(recovered);
            tvIdDeath.setText(death);
            tvLocate.setText(nama);
        });
    }
}
