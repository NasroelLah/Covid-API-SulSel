package com.unhas.covid.api;

public class Api {
    public static final String MATHDROID_BASE_URL = "https://covid19.mathdro.id";
    public static final String INDO_BASE_URL = "https://indonesia-covid-19.mathdro.id/";
    public static final String INDO_BASE_URL_ID = "/api";
    public static final String KAWAL_BASE_URL = "https://api.kawalcorona.com";
    public static final String KAWAL_END_POINT_IND = "/indonesia";
    public static final String KAWAL_END_POINT_IND_PROV = "/indonesia/provinsi/";
    public static final String SULSEL_BASE_URL = "https://covid.nas.my.id/";
}
