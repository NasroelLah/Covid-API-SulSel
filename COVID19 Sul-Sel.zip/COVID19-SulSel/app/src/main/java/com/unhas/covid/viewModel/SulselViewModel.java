package com.unhas.covid.viewModel;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.unhas.covid.api.ApiEndPoint;
import com.unhas.covid.api.ApiService;
import com.unhas.covid.model.SulselModel;

import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;
import retrofit2.Retrofit;

public class SulselViewModel extends ViewModel {
    private MutableLiveData<List<SulselModel>> mutableLiveData = new MutableLiveData<>();

    public void setSulselData(){
        Retrofit retrofit = ApiService.getRetrofitServiceSulsel();
        ApiEndPoint apiEndPoint = retrofit.create(ApiEndPoint.class);
        Call<List<SulselModel>> call = apiEndPoint.getSulselData();
        call.enqueue(new Callback<List<SulselModel>>() {
            @Override
            public void onResponse(Call<List<SulselModel>> call, Response<List<SulselModel>> response) {
                if (response.isSuccessful()){
                    List<SulselModel> sulselModelList = null;
                    if (response.body() != null){
                        sulselModelList = response.body();
                    }
                    mutableLiveData.postValue(sulselModelList);
                }
            }

            @Override
            public void onFailure(Call<List<SulselModel>> call, Throwable t) {

            }
        });
    }
    public MutableLiveData<List<SulselModel>> getSulselData(){return mutableLiveData;}
}
