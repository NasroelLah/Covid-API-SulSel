package com.unhas.covid.ui.activities;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import com.unhas.covid.R;

public class SulselActivity extends AppCompatActivity {
    private TextView tvOdp;
    private TextView tvPdp;
    private TextView tvPositif;
    private TextView tvTotalOdp;
    private TextView tvTotalPdp;
    private TextView tvTotalPositif;
    private TextView tvSembuh;
    private TextView tvMeninggal;
    private TextView tvPdpMeninggal;
    private TextView tvPdpNegatif;
    private TextView tvSelesaiOdp;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sulsel);
        tvOdp = findViewById(R.id.txt_odp);
        tvPdp = findViewById(R.id.txt_pdp);
        tvPositif = findViewById(R.id.txt_positif);
        tvTotalOdp = findViewById(R.id.txt_odp01);
        tvSelesaiOdp = findViewById(R.id.txt_odp02);
        tvTotalPdp = findViewById(R.id.txt_pdp01);
        tvPdpNegatif = findViewById(R.id.txt_pdp12);
        tvPdpMeninggal = findViewById(R.id.txt_pdp13);
        tvTotalPositif = findViewById(R.id.txt_pos2);
        tvSembuh = findViewById(R.id.txt_pos3);
        tvMeninggal = findViewById(R.id.txt_pos4);

    }
}
