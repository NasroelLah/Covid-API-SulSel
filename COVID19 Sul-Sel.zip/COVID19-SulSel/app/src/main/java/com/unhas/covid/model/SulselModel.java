package com.unhas.covid.model;

import com.google.gson.annotations.SerializedName;

public class SulselModel {
    @SerializedName("odp")
    private String odp;
    @SerializedName("pdp")
    private String pdp;
    @SerializedName("positif")
    private String positif;
    @SerializedName("sembuh")
    private String sembuh;
    @SerializedName("die")
    private String meninggal;
    @SerializedName("tOdp")
    private String totalOdp;
    @SerializedName("tPdp")
    private String totalPdp;
    @SerializedName("tPos")
    private String totalPositif;
    @SerializedName("sOdp")
    private String selesaiOdp;
    @SerializedName("mPdp")
    private String diePdp;
    @SerializedName("nPdp")
    private String negatifPdp;
    @SerializedName("mIso")
    private String isolasiMandiri;
    @SerializedName("rIso")
    private String isolasiRs;

    public SulselModel(String odp, String pdp, String positif, String totalOdp, String totalPdp, String totalPositif, String selesaiOdp, String negatifPdp, String diePdp, String isolasiMandiri, String isolasiRs, String sembuh, String meninggal){
        this.odp = odp;
        this.pdp = pdp;
        this.positif = positif;
        this.sembuh = sembuh;
        this.meninggal = meninggal;
        this.diePdp = diePdp;
        this.selesaiOdp = selesaiOdp;
        this.isolasiMandiri = isolasiMandiri;
        this.isolasiRs = isolasiRs;
        this.negatifPdp = negatifPdp;
        this.totalOdp = totalOdp;
        this.totalPdp = totalPdp;
        this.totalPositif = totalPositif;
    }

    public String getOdp() {
        return odp;
    }

    public String getPdp() {
        return pdp;
    }

    public String getPositif() {
        return positif;
    }

    public String getSembuh() {
        return sembuh;
    }

    public String getMeninggal() {
        return meninggal;
    }

    public String getTotalOdp() {
        return totalOdp;
    }

    public String getTotalPdp() {
        return totalPdp;
    }

    public String getTotalPositif() {
        return totalPositif;
    }

    public String getSelesaiOdp() {
        return selesaiOdp;
    }

    public String getDiePdp() {
        return diePdp;
    }

    public String getNegatifPdp() {
        return negatifPdp;
    }

    public String getIsolasiMandiri() {
        return isolasiMandiri;
    }

    public String getIsolasiRs() {
        return isolasiRs;
    }
}
