package com.unhas.covid.api;

import com.unhas.covid.model.CountryModel;
import com.unhas.covid.model.SulselModel;
import com.unhas.covid.model.provinsi.Provinsi;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface ApiEndPoint {
    @GET(Api.KAWAL_END_POINT_IND_PROV)
    Call<List<Provinsi>> getKawalProvinsi();
    @GET(Api.KAWAL_END_POINT_IND)
    Call<List<CountryModel>> getKawalIndo();
    @GET(Api.SULSEL_BASE_URL)
    Call<List<SulselModel>> getSulselData();
}
