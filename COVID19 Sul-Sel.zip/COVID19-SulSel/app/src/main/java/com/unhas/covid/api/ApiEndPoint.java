package com.unhas.covid.api;

import com.unhas.covid.model.Confirmed;
import com.unhas.covid.model.CountryModel;
import com.unhas.covid.model.Death;
import com.unhas.covid.model.GlobalDataModel;
import com.unhas.covid.model.GlobalModel;
import com.unhas.covid.model.Recovered;
import com.unhas.covid.model.provinsi.Provinsi;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface ApiEndPoint {
    @GET(Api.MATHDROID_END_POINT_SUMMARY_WORLD)
    Call<GlobalModel> getSummaryGlobal();

    @GET(Api.MATHDROID_END_POINT_CONFIRM)
    Call<List<GlobalDataModel>> getGlobalData();

    @GET(Api.MATHDROID_END_POINT_CONFIRM)
    Call<List<Confirmed>> getGlobalConfirmed();

    @GET(Api.MATHDROID_END_POINT_RECOVERED)
    Call<List<Recovered>> getGlobalRecovered();

    @GET(Api.MATHDROID_END_POINT_DEATH)
    Call<List<Death>> getGlobalDeath();

    //kawal
    @GET(Api.KAWAL_END_POINT_IND_PROV)
    Call<List<Provinsi>> getKawalProvinsi();

    @GET(Api.KAWAL_END_POINT_IND)
    Call<List<CountryModel>> getKawalIndo();

    //indoMathdroid
    @GET(Api.INDO_BASE_URL_ID)
    Call<CountryModel> getIndo();
}
